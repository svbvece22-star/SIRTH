import numpy as np
from collections import Counter

def LoadBalancing(pos):
    Capacity = np.load(f'pre_evaluated/Capacity.npy', allow_pickle=True)
    pos = np.round(np.random.uniform(0,9,400))
    from collections import Counter
    x = Counter(pos)
    low_bound, up_bound,equal_bound,overloadtask = [],[],[],[]
    for i in range(0,len(Capacity)):
        if x[i] < Capacity[i]:
            low_bound.append(i)
        elif x[i]>Capacity[i]:
            overloadtask.append(x[i]-Capacity[i])
            up_bound.append(i)
        elif x[0] == Capacity[0]:
            equal_bound.append(i)
    return low_bound,up_bound,overloadtask

