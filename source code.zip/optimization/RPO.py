from numpy.random import uniform
from optimization.root import Root
from numpy.random import uniform
import numpy as np


class BaseRPO(Root):
    """
    % Ref paper:
    %% Red Panda Optimization Algorithm: An effective
    % bio-inspired metaheuristic algorithm for solving
    % engineering optimization problems
    % Author: HADI GIVI
    % https://www.researchgate.net/publication/371367191_Red_Panda_Optimization_Algorithm_An_effective_bio-inspired_metaheuristic_algorithm_for_solving_engineering_optimization_problems
    % Code implemented: RN
    """

    def __init__(self, obj_func=None, lb=None, ub=None, problem_size=50, batch_size=10, verbose=False,
                 epoch=700, pop_size=50):
        Root.__init__(self, obj_func, lb, ub, problem_size, batch_size, verbose)
        self.epoch = epoch
        self.pop_size = pop_size

    def create_solution(self, minmax=0):
        position = self.lb+uniform(0, 1, (self.problem_size))*(self.ub-self.lb)    # eqn 1 & 2
        fitness = self.get_fitness_position(position=position, minmax=minmax)
        return [position, fitness]

    def check_bounds(self, xij_new):
        for i in range(len(xij_new)):
            xij_new[i, xij_new[i] > self.ub[0]] = np.random.uniform(self.lb[0], self.ub[0])
            xij_new[i, xij_new[i] < self.lb[0]] = np.random.uniform(self.lb[0], self.ub[0])
        return xij_new

    def train(self):
        pop = [self.create_solution(minmax=0) for _ in range(self.pop_size)]
        g_best = self.get_global_best_solution(pop, self.ID_FIT, self.ID_MIN_PROB)

        for epoch in range(self.epoch):

            for i in range(self.pop_size):
                # Phase 1: : The strategy of red pandas in foraging
                # Update food positions set for the 𝑖th RPO member using (4).
                PFS, SFS = [],[]
                for k in range(self.pop_size):
                    if (pop[k][self.ID_FIT]<pop[i][self.ID_FIT]) and (k!=i):
                        PFS.append(pop[k][self.ID_POS])
                if len(PFS) == 0:
                    PFS = g_best[self.ID_POS]

                # Determine the selected food by the ith red panda at random
                id = np.random.randint(np.shape(PFS)[0])
                SFS = PFS[id]
                I = np.random.randint(2)
                # Calculate new position of the 𝑖th RPO member based on the 1st phase of RPO using (5).
                X_P1 = pop[i][self.ID_POS]+uniform()*(SFS - I*pop[i][self.ID_POS])
                X_P1 = self.check_bounds(X_P1)
                F_P1 = self.get_fitness_position(X_P1)
                # Update the 𝑖th RPO member using (6).
                if F_P1 < pop[i][self.ID_FIT]:
                    pop[i][self.ID_POS] = X_P1
                    pop[i][self.ID_FIT] = F_P1

                # Phase 2: Skill in climbing and resting on the tree
                # Calculate new position of the 𝑖th RPO member based on the 2nd phase of RPO using (7)
                X_P2 = pop[i][self.ID_POS]+(self.lb+uniform()*(self.ub-self.lb))/epoch
                X_P2 = self.check_bounds(X_P2)
                F_P2 = self.get_fitness_position(X_P2)
                # Update the 𝑖th RPO member using (8)
                if F_P2 < pop[i][self.ID_FIT]:
                    pop[i][self.ID_POS] = X_P2
                    pop[i][self.ID_FIT] = F_P2

                # Update the best candidate solution
                # batch size idea
                if i % self.batch_size:
                    g_best = self.update_global_best_solution(pop, self.ID_MIN_PROB, g_best)
            self.loss_train.append(g_best[self.ID_FIT])
            if self.verbose:
                print("Epoch: {}, Best fit: {}".format(epoch + 1, g_best[self.ID_FIT]))
        self.solution = g_best
        return g_best[self.ID_POS], g_best[self.ID_FIT], self.loss_train


class HybridRPO(Root):
    """
    % Ref paper:
    %% Red Panda Optimization Algorithm: An effective
    % bio-inspired metaheuristic algorithm for solving
    % engineering optimization problems
    % Author: HADI GIVI
    % https://www.researchgate.net/publication/371367191_Red_Panda_Optimization_Algorithm_An_effective_bio-inspired_metaheuristic_algorithm_for_solving_engineering_optimization_problems
    % Code implemented: RN
    """

    def __init__(self, obj_func=None, lb=None, ub=None, problem_size=50, batch_size=10, verbose=False,
                 epoch=700, pop_size=50):
        Root.__init__(self, obj_func, lb, ub, problem_size, batch_size, verbose)
        self.epoch = epoch
        self.pop_size = pop_size

    def create_solution(self, minmax=0):
        position = self.lb+uniform(0, 1, (self.problem_size))*(self.ub-self.lb)    # eqn 1 & 2
        fitness = self.get_fitness_position(position=position, minmax=minmax)
        return [position, fitness]

    def check_bounds(self, xij_new):
        for i in range(len(xij_new)):
            xij_new[i, xij_new[i] > self.ub[0]] = np.random.uniform(self.lb[0], self.ub[0])
            xij_new[i, xij_new[i] < self.lb[0]] = np.random.uniform(self.lb[0], self.ub[0])
        return xij_new

    def train(self):
        pop = [self.create_solution(minmax=0) for _ in range(self.pop_size)]
        g_best = self.get_global_best_solution(pop, self.ID_FIT, self.ID_MIN_PROB)

        for epoch in range(self.epoch):

            for i in range(self.pop_size):
                # Phase 1: : The strategy of red pandas in foraging
                # Update food positions set for the 𝑖th RPO member using (4).
                PFS, SFS = [],[]
                for k in range(self.pop_size):
                    if (pop[k][self.ID_FIT]<pop[i][self.ID_FIT]) and (k!=i):
                        PFS.append(pop[k][self.ID_POS])
                if len(PFS) == 0:
                    PFS = g_best[self.ID_POS]

                # Determine the selected food by the ith red panda at random
                id = np.random.randint(np.shape(PFS)[0])
                SFS = PFS[id]
                I = np.random.randint(2)
                # Calculate new position of the 𝑖th RPO member based on the 1st phase of RPO using (5).
                # X_P1 = pop[i][self.ID_POS]+uniform()*(SFS - I*pop[i][self.ID_POS])
                ### Updation 1 ###
                c1 = np.random.uniform()
                c2 = np.random.uniform()
                r1 = np.random.uniform(0, 1)
                r2 = np.random.uniform(0, 1)
                randi = np.random.uniform(0, 1)
                X_P1 = pop[i][self.ID_POS] + c1 * r1 * (g_best[self.ID_POS] - pop[i][self.ID_POS]) + c2 * r2 * (randi - pop[i][self.ID_POS])
                ######

                X_P1 = self.check_bounds(X_P1)
                F_P1 = self.get_fitness_position(X_P1)
                # Update the 𝑖th RPO member using (6).
                if F_P1 < pop[i][self.ID_FIT]:
                    pop[i][self.ID_POS] = X_P1
                    pop[i][self.ID_FIT] = F_P1

                # Phase 2: Skill in climbing and resting on the tree
                # Calculate new position of the 𝑖th RPO member based on the 2nd phase of RPO using (7)
                # X_P2 = pop[i][self.ID_POS]+(self.lb+uniform()*(self.ub-self.lb))/epoch
                ### Updation 2 ###
                r5 = np.random.uniform()
                r6 = np.random.uniform()
                a = 1/2
                beta = 0.6
                max_iter = self.epoch
                if epoch == 0:
                    r4 = a - (a / (epoch + 1e-1)) / max_iter
                else:
                    r4 = a - (a / epoch)/max_iter

                if np.mean(pop[i][self.ID_POS]) < 0.5:
                    X_P2 = pop[i][self.ID_POS]+(self.lb+uniform()*(self.ub-self.lb))/epoch + r4 * np.sin(r5) * (np.abs(r6 * pop[i][self.ID_POS] - pop[i][self.ID_POS]) + beta)
                elif np.mean(pop[i][self.ID_POS]) >= 0.5:
                    X_P2 = pop[i][self.ID_POS]+(self.lb+uniform()*(self.ub-self.lb))/epoch + r4 * np.cos(r5) * (np.abs(r6 * pop[i][self.ID_POS] - pop[i][self.ID_POS]) + beta)


                X_P2 = self.check_bounds(X_P2)
                F_P2 = self.get_fitness_position(X_P2)
                # Update the 𝑖th RPO member using (8)
                if F_P2 < pop[i][self.ID_FIT]:
                    pop[i][self.ID_POS] = X_P2
                    pop[i][self.ID_FIT] = F_P2

                # Update the best candidate solution
                # batch size idea
                if i % self.batch_size:
                    g_best = self.update_global_best_solution(pop, self.ID_MIN_PROB, g_best)
            self.loss_train.append(g_best[self.ID_FIT])
            if self.verbose:
                print("Epoch: {}, Best fit: {}".format(epoch + 1, g_best[self.ID_FIT]))
        self.solution = g_best
        return g_best[self.ID_POS], g_best[self.ID_FIT], self.loss_train
