import numpy as np
#!/usr/bin/env python
# ------------------------------------------------------------------------------------------------------%
# Created by "Thieu Nguyen" at 14:52, 17/03/2020                                                        %
#                                                                                                       %
#       Email:      nguyenthieu2102@gmail.com                                                           %
#       Homepage:   https://www.researchgate.net/profile/Thieu_Nguyen6                                  %
#       Github:     https://github.com/thieu1995                                                  %
#-------------------------------------------------------------------------------------------------------%

from numpy.random import uniform, choice
from numpy import array, mean, pi, sin, cos, max, sinh, cosh
from optimization.root import Root


class BaseRTH(Root):
    """
   Red‐tailed hawk algorithm for numerical optimization and real‐world problems
   Seydali Ferahtia1,2, Azeddine Houari1, Hegazy Rezk3, Ali Djerioui2, Mohamed Machmoum1
   Saad Motahhir4* & MouradAit‐Ahmed1,j
    Link:
       https://www.nature.com/articles/s41598-023-38778-3
    """

    def __init__(self, obj_func=None, lb=None, ub=None, problem_size=50, batch_size=10, verbose=True,
                 epoch=750, pop_size=100, A=15, R0=0.5,r = 1.5):
        Root.__init__(self, obj_func, lb, ub, problem_size, batch_size, verbose)
        self.epoch = epoch
        self.pop_size = pop_size
        self.A=A          # default: 10, determining the corner between point search in the central point, in [5, 10]
        self.R0 = R0           # default: 1.5, determining the number of search cycles, in [0.5, 2]
        self.r = r   # default: 2, parameter for controlling the changes in position, in [1.5, 2]

    def _create_x_y_x1_y1_(self):
        """ Using numpy vector for faster computational time """
        ## Eq. 2
        phi = self.a * pi * uniform(0, 1, self.pop_size)
        r = phi + self.R * uniform(0, 1, self.pop_size)
        xr, yr = r * sin(phi), r * cos(phi)

        ## Eq. 3
        r1 = phi1 = self.a * pi * uniform(0, 1, self.pop_size)
        xr1, yr1 = r1 * sinh(phi1), r1 * cosh(phi1)

        x_list = xr / max(xr)
        y_list = yr / max(yr)
        x1_list = xr1 / max(xr1)
        y1_list = yr1 / max(yr1)
        return x_list, y_list, x1_list, y1_list

    def polr(self,A, R0, N, t, MaxIt, r):
        ## Set parameters
        th = (1 + t / MaxIt) * A * pi * np.random.rand(N, 1)
        R = (r - t / MaxIt) * R0 * np.random.rand(N, 1)
        xR = R * sin(th)
        yR = R * cos(th)
        xR = xR / max(abs(xR))
        yR = yR / max(abs(yR))
        return xR, yR

    def train(self):
        # Initialization population and fitness
        pop = [self.create_solution() for _ in range(self.pop_size)]
        g_best = self.get_global_best_solution(pop, self.ID_FIT, self.ID_MIN_PROB)

        for epoch in range(self.epoch):
            # 1 - High Soaring
            Xmean = np.mean(pop[self.ID_POS])
            TF = 1 + sin(2.5 - epoch / self.epoch)  #TF
            for i in range(0, self.pop_size):
                pos_new  = g_best[self.ID_POS] + (Xmean - pop[i][self.ID_POS]) * self.step_size_by_levy_flight(case=2) * TF
                pos_new = self.amend_position_faster(pos_new)
                fit = self.get_fitness_position(pos_new)
                if fit < pop[i][self.ID_FIT]:
                    pop[i] = [pos_new, fit]
                    if pop[i][self.ID_FIT] < g_best[self.ID_FIT]:
                        g_best = [pos_new, fit]

            # 2 - Low Soaring
            Xmean = np.mean(pop[self.ID_POS])
            for i in range(0, self.pop_size-1):
                aa = np.random.permutation(self.pop_size)
                pop_= pop
                for ii in range(0,len(aa)):
                    pop_[ii][self.ID_POS] = pop[aa[ii]][self.ID_POS]
                    pop_[ii][self.ID_FIT] = pop[aa[ii]][self.ID_FIT]
                pop = pop_
                x, y = self.polr(self.A, self.R0, self.pop_size, epoch,self.epoch, self.r)
                StepSize = pop[i][self.ID_POS]-Xmean
                pos_new = g_best[self.ID_POS] + (y[i] + x[i]) * StepSize
                pos_new = self.amend_position_faster(pos_new)
                fit = self.get_fitness_position(pos_new)
                if fit < pop[i][self.ID_FIT]:
                    pop[i] = [pos_new, fit]
                    if pop[i][self.ID_FIT] < g_best[self.ID_FIT]:
                        g_best = [pos_new, fit]

            ## 3 - Stopping & Swooping
            Xmean = np.mean(pop[self.ID_POS])
            TF = 1 + 0.5 * sin(2.5 - epoch/self.epoch)
            for i in range(0, self.pop_size - 1):
                bb = np.random.permutation(self.pop_size)
                pop_ = pop
                for ii in range(len(bb)):
                    pop_[ii][self.ID_POS] = pop[bb[ii]][self.ID_POS]
                    pop_[ii][self.ID_FIT] = pop[bb[ii]][self.ID_FIT]
                pop = pop_
                x, y = self.polr(self.A, self.R0, self.pop_size, epoch,self.epoch, self.r)
                alpha = (np.sin(2.5 - epoch/self.epoch) ** 2)
                G = 2 * (1 - (epoch/self.epoch))
                StepSize1 = 1 * pop[i][self.ID_POS] - TF * Xmean
                StepSize2 = G * pop[i][self.ID_POS]-TF * g_best[self.ID_POS]
                pos_new = alpha * g_best[self.ID_POS] + x[i] * StepSize1 + y[i] * StepSize2;
                pos_new = self.amend_position_faster(pos_new)
                fit = self.get_fitness_position(pos_new)
                if fit < pop[i][self.ID_FIT]:
                    pop[i] = [pos_new, fit]
                    if pop[i][self.ID_FIT] < g_best[self.ID_FIT]:
                        g_best = [pos_new, fit]

            self.loss_train.append(g_best[self.ID_FIT])
            if self.verbose:
                print("> Epoch: {}, Best fit: {}".format(epoch + 1, g_best[self.ID_FIT]))
        self.solution = g_best
        return g_best[self.ID_POS], g_best[self.ID_FIT], self.loss_train

class BaseImpRTH(Root):
    """
   Red‐tailed hawk algorithm for numerical optimization and real‐world problems
   Seydali Ferahtia1,2, Azeddine Houari1, Hegazy Rezk3, Ali Djerioui2, Mohamed Machmoum1
   Saad Motahhir4* & MouradAit‐Ahmed1,j
    Link:
       https://www.nature.com/articles/s41598-023-38778-3
    """

    def __init__(self, obj_func=None, lb=None, ub=None, problem_size=50, batch_size=10, verbose=True,
                 epoch=750, pop_size=100, A=15, R0=0.5,r = 1.5):
        Root.__init__(self, obj_func, lb, ub, problem_size, batch_size, verbose)
        self.epoch = epoch
        self.pop_size = pop_size
        self.A=A          # default: 10, determining the corner between point search in the central point, in [5, 10]
        self.R0 = R0           # default: 1.5, determining the number of search cycles, in [0.5, 2]
        self.r = r   # default: 2, parameter for controlling the changes in position, in [1.5, 2]
        self.problem_size = problem_size
    def _create_x_y_x1_y1_(self):
        """ Using numpy vector for faster computational time """
        ## Eq. 2
        phi = self.a * pi * uniform(0, 1, self.pop_size)
        r = phi + self.R * uniform(0, 1, self.pop_size)
        xr, yr = r * sin(phi), r * cos(phi)

        ## Eq. 3
        r1 = phi1 = self.a * pi * uniform(0, 1, self.pop_size)
        xr1, yr1 = r1 * sinh(phi1), r1 * cosh(phi1)

        x_list = xr / max(xr)
        y_list = yr / max(yr)
        x1_list = xr1 / max(xr1)
        y1_list = yr1 / max(yr1)
        return x_list, y_list, x1_list, y1_list

    def polr(self,A, R0, N, t, MaxIt, r):
        ## Set parameters
        th = (1 + t / MaxIt) * A * pi * np.random.rand(N, 1)
        R = (r - t / MaxIt) * R0 * np.random.rand(N, 1)
        xR = R * sin(th)
        yR = R * cos(th)
        xR = xR / max(abs(xR))
        yR = yR / max(abs(yR))
        return xR, yR

    def train(self):
        # Initialization population and fitness
        pop = [self.create_solution() for _ in range(self.pop_size)]
        g_best = self.get_global_best_solution(pop, self.ID_FIT, self.ID_MIN_PROB)

        for epoch in range(self.epoch):
            # 1 - High Soaring
            Xmean = np.mean(pop[self.ID_POS])
            TF = 1 + sin(2.5 - epoch / self.epoch)  #TF
            for i in range(0, self.pop_size):
                # pos_new  = g_best[self.ID_POS] + (Xmean - pop[i][self.ID_POS]) * self.step_size_by_levy_flight(case=2) * TF
                eta = np.random.uniform(0, 1)
                gamma = np.log(1 * (2 / (1 + eta * np.exp((-2 * epoch) / self.epoch))))
                pos_new  = (g_best[self.ID_POS] * gamma) + (Xmean - pop[i][self.ID_POS]) * self.step_size_by_levy_flight(case=2) * TF * gamma
                pos_new = self.amend_position_faster(pos_new)
                fit = self.get_fitness_position(pos_new)
                if fit < pop[i][self.ID_FIT]:
                    pop[i] = [pos_new, fit]
                    if pop[i][self.ID_FIT] < g_best[self.ID_FIT]:
                        g_best = [pos_new, fit]

            # 2 - Low Soaring
            Xmean = np.mean(pop[self.ID_POS])
            for i in range(0, self.pop_size-1):
                aa = np.random.permutation(self.pop_size)
                pop_= pop
                for ii in range(0,len(aa)):
                    pop_[ii][self.ID_POS] = pop[aa[ii]][self.ID_POS]
                    pop_[ii][self.ID_FIT] = pop[aa[ii]][self.ID_FIT]
                pop = pop_
                x, y = self.polr(self.A, self.R0, self.pop_size, epoch,self.epoch, self.r)
                StepSize = pop[i][self.ID_POS]-Xmean
                # pos_new = g_best[self.ID_POS] + (y[i] + x[i]) * StepSize

                Pmin, Pmax = 0, 1
                a = ((Pmin * self.epoch) - Pmax)/ self.epoch-1
                b = (Pmax - Pmin)/ self.epoch-1
                p = (1 / self.problem_size) + np.sum(a + b * self.epoch) + 1
                pos_new = g_best[self.ID_POS] + ((y[i] * p) + (x[i] * p)) * StepSize
                pos_new = self.amend_position_faster(pos_new)
                fit = self.get_fitness_position(pos_new)
                if fit < pop[i][self.ID_FIT]:
                    pop[i] = [pos_new, fit]
                    if pop[i][self.ID_FIT] < g_best[self.ID_FIT]:
                        g_best = [pos_new, fit]

            ## 3 - Stopping & Swooping
            Xmean = np.mean(pop[self.ID_POS])
            TF = 1 + 0.5 * sin(2.5 - epoch/self.epoch)
            for i in range(0, self.pop_size - 1):
                bb = np.random.permutation(self.pop_size)
                pop_ = pop
                for ii in range(len(bb)):
                    pop_[ii][self.ID_POS] = pop[bb[ii]][self.ID_POS]
                    pop_[ii][self.ID_FIT] = pop[bb[ii]][self.ID_FIT]
                pop = pop_
                x, y = self.polr(self.A, self.R0, self.pop_size, epoch,self.epoch, self.r)
                alpha = (np.sin(2.5 - epoch/self.epoch) ** 2)
                G = 2 * (1 - (epoch/self.epoch))
                StepSize1 = 1 * pop[i][self.ID_POS] - TF * Xmean
                StepSize2 = G * pop[i][self.ID_POS]-TF * g_best[self.ID_POS]
                pos_new = alpha * g_best[self.ID_POS] + x[i] * StepSize1 + y[i] * StepSize2;
                pos_new = self.amend_position_faster(pos_new)
                fit = self.get_fitness_position(pos_new)
                if fit < pop[i][self.ID_FIT]:
                    pop[i] = [pos_new, fit]
                    if pop[i][self.ID_FIT] < g_best[self.ID_FIT]:
                        g_best = [pos_new, fit]

            self.loss_train.append(g_best[self.ID_FIT])
            if self.verbose:
                print("> Epoch: {}, Best fit: {}".format(epoch + 1, g_best[self.ID_FIT]))
        self.solution = g_best
        return g_best[self.ID_POS], g_best[self.ID_FIT], self.loss_train
