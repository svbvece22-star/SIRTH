from numpy.random import uniform, normal, randint
from numpy import pi, sin, cos, zeros, minimum, maximum, abs, where, sign
from copy import deepcopy
from mealpy.root import Root
import numpy as np
from math import gamma


class BaseSTO(Root):
    """
        The original version of: Siberian Tiger Optimization Algorithm
    """

    def __init__(self, obj_func=None, lb=None, ub=None, problem_size=50, batch_size=10, verbose=True,
                 epoch=750, pop_size=100):
        Root.__init__(self, obj_func, lb, ub, problem_size, batch_size, verbose)
        self.epoch = epoch
        self.pop_size = pop_size

    def check_bounds(self, xij_new):
        for i in range(xij_new.shape[0]):
            if xij_new[i] > self.ub[i]:
                xij_new[i] = np.random.uniform(self.lb[i], self.ub[i])
            elif xij_new[i] < self.lb[i]:
                xij_new[i] = np.random.uniform(self.lb[i], self.ub[i])
        return xij_new

    def create_solution(self, minmax=0):
        pos = self.lb + np.random.uniform(0, 1) * (self.ub - self.lb)
        fit = self.get_fitness_position(pos)
        return [pos, fit]

    def train(self):
        def pre_hunting(X,  k):
            r = np.random.uniform(0, 1)
            CP = X.__len__()
            prey_index = np.random.choice(CP)
            TP = X[prey_index]
            I = np.random.randint(1, 3)
            new_position = X[k][0] + r * (TP[0] - I * X[k][0])          # ----eqn(5)
            return new_position

        pop = [self.create_solution() for _ in range(self.pop_size)] # Generate the initial population matrix
        pop = deepcopy(pop)
        g_best = self.get_global_best_solution(pop=pop, id_fit=self.ID_FIT, id_best=self.ID_MIN_PROB) # Evaluate the objective function
        # fit_new = self.get_fitness_position(pop)
        for epoch in range(self.epoch):         # For t = 1 to T
            for i in range(self.pop_size):      # For i = 1 to N
                # Phase 1: pre_hunting
                x_new = pre_hunting(pop, i)
                x_new = self.check_bounds(x_new)
                fit_new = self.get_fitness_position(x_new)
                # Update current position, current velocity and compare with past position, past fitness (local best)
                if fit_new < pop[i][self.ID_FIT]:
                    pop[i] = [x_new, fit_new]

                r = np.random.uniform(0, 1)
                x_new = pop[i][0] + r * (self.ub - self.lb) / epoch      # -----eqn(7)
                x_new = self.check_bounds(x_new)
                fit_new = self.get_fitness_position(x_new)
                # Update current position, current velocity and compare with past position, past fitness (local best)
                if fit_new < pop[i][self.ID_FIT]:
                    pop[i] = [x_new, fit_new]

                # Phase2: Fighting with bear
                prey_index = np.random.choice(pop.__len__())
                XP = pop[prey_index]
                I = np.random.randint(1, 3)
                if XP[1] < pop[i][1]:
                    x_new = pop[i][0] + r * (XP[0] - I * pop[i][0])    # -----eqn(9)
                    fit_new = self.get_fitness_position(x_new)
                else:
                    x_new = pop[i][0] + r * (pop[i][0] - I * XP[0])    # -----eqn(9)
                    fit_new = self.get_fitness_position(x_new)

                if fit_new < pop[i][self.ID_FIT]:
                    pop[i] = [x_new, fit_new]

                r = np.random.uniform(0, 1)
                x_new = pop[i][0] + r * (self.ub - self.lb) / epoch  # -----eqn(11)
                x_new = self.check_bounds(x_new)
                fit_new = self.get_fitness_position(x_new)
                # Update current position, current velocity and compare with past position, past fitness (local best)
                if fit_new < pop[i][self.ID_FIT]:
                    pop[i] = [x_new, fit_new]

                ## batch size idea
                if i % self.batch_size:
                    g_best = self.update_global_best_solution(pop, self.ID_MIN_PROB, g_best)
            self.loss_train.append(g_best[self.ID_FIT])
            if self.verbose:
                print(">Epoch: {}, Best fit: {}".format(epoch+1, g_best[self.ID_FIT]))
        self.solution = g_best
        return g_best[self.ID_POS].flatten(), g_best[self.ID_FIT], self.loss_train