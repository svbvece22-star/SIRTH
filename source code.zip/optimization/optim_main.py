from time import time
import numpy as np
import pandas as pd
from numpy import array as ar
from optimization import RTH, KOA, lyrebird, Pufferfish, RPO, SPSO,RHA,BPSO
from LoadBalancing import LoadBalancing


def sort_with_index(numbers):
    sorted_with_index = sorted(enumerate(numbers), key=lambda x: x[1])  # Sort by value
    ids, vals = zip(*sorted_with_index)  # Unpack into separate lists
    return list(ids), list(vals)

def objfun(sol):
    APHRank = np.load(f'pre_evaluated/APHRank.npy', allow_pickle=True)
    if len(sol) < 400:
        APHRank = APHRank[0:len(sol)]
    fcm_data = np.load(f'pre_evaluated/clustering_idx.npy', allow_pickle=True)
    task_runtime = np.load(f'pre_evaluated/task_runtime.npy', allow_pickle=True)

    w1, w2, w3, w4 = 0.25, 0.25, 0.25, 0.25
    soln = np.round(sol)
    ## ranking
    rankidx = np.zeros((len(sol), 2))
    uni = np.unique(soln)
    for i in range(0, len(uni)):
        task_count = np.where(soln == uni[i])  # task count in i th VM
        for j in range(0, len(task_count[0])):
            rankidx[task_count[0][j], 0] = APHRank[task_count[0][j]]
            rankidx[task_count[0][j], 1] = soln[task_count[0][j]]
    ids, vals = sort_with_index(rankidx[:, 0])
    new_soln = rankidx[ids, 1]

    ## clustering
    VMidx = np.zeros((len(sol), 2))
    for i in range(0, len(sol)):
        search_value = new_soln[i]
        for index, inner_list in enumerate(fcm_data):
            if search_value in inner_list:
                VMidx[i, 0] = search_value
                VMidx[i, 1] = index

    indices = new_soln.astype(int)  # Convert all elements of new_soln to integers
    task_runtime[indices]  # Now you can use the integer indices to index task_runtime
    cluster_runtime = []
    for i in range(0, 5):
        task_count_ = np.where(VMidx[:, 1] == i)
        cluster_runtime.append(
            task_runtime[task_count_[0]] / 1000000000)  ### convert microseconds into sseconds 1 sec = 1x10^6 microsec
    ## Makespan
    CTime = []
    for i in range(0, 5):
        CTime.append(np.sum(cluster_runtime[i]))
    ms = np.max(CTime)

    ## Resource Utilization
    VM = len(uni)
    ru = np.sum(CTime) / (ms * VM)
    ## Execution time
    et = np.sum(CTime)
    ## Degree of Imbalance
    dt = []
    for i in range(0, 5):
        T = cluster_runtime[i]
        if len(T) > 0:
            Tmax = np.max(T)
            Tmin = np.min(T)
            Tavg = np.mean(T)
            Tdt = (Tmax - Tmin) / Tavg
        else:
            Tdt = 0
        dt.append(Tdt)
    di = np.mean(dt)
    fit = (w1 * ms) + (w2 * di) + (w3 * ru) + (w4 * et)
    return fit

def base3(obj_func, **kwargs):
    start = time()
    rpo_ = BPSO.BaseBPSO(obj_func, **kwargs)
    # rpo_ = RHA.BaseRHA(obj_func, **kwargs)
    rpo_pos1, rpo_fit1, rpo_loss1 = rpo_.train()
    [low_bound,up_bound,overloadtask] = LoadBalancing(rpo_pos1)
    lb1 = [0]
    ub1 = [len(low_bound)]
    prblm_size = int(sum(overloadtask) if isinstance(overloadtask, (list, np.ndarray)) else 0)
    rpo_ = BPSO.BaseBPSO(obj_func, lb=lb1, ub=ub1, problem_size=prblm_size, batch_size=5,
                                                        verbose=False, epoch=50, pop_size=10)
    rpo_pos1, rpo_fit1, rpo_loss1 = rpo_.train()
    LoadBalancing(rpo_pos1)
    ct = time() - start  # computation time
    return ['base2', ct, rpo_pos1, rpo_fit1, rpo_loss1]


def base2(obj_func, **kwargs):
    start = time()
    rpo_ = RHA.BaseRHA(obj_func, **kwargs)
    rpo_pos1, rpo_fit1, rpo_loss1 = rpo_.train()
    [low_bound,up_bound,overloadtask] = LoadBalancing(rpo_pos1)
    lb1 = [0]
    ub1 = [len(low_bound)]
    prblm_size = int(sum(overloadtask) if isinstance(overloadtask, (list, np.ndarray)) else 0)
    rpo_ = RHA.BaseRHA(obj_func, lb=lb1, ub=ub1, problem_size=prblm_size, batch_size=5,
                                                        verbose=False, epoch=50, pop_size=10)
    rpo_pos1, rpo_fit1, rpo_loss1 = rpo_.train()
    ct = time() - start  # computation time
    return ['base2', ct, rpo_pos1, rpo_fit1, rpo_loss1]

def base1(obj_func, **kwargs):
    start = time()
    rpo_ = SPSO.BaseSPSO(obj_func, **kwargs)
    rpo_pos1, rpo_fit1, rpo_loss1 = rpo_.train()
    [low_bound,up_bound,overloadtask] = LoadBalancing(rpo_pos1)
    lb1 = [0]
    ub1 = [len(low_bound)]
    prblm_size = int(sum(overloadtask) if isinstance(overloadtask, (list, np.ndarray)) else 0)
    rpo_ = SPSO.BaseSPSO(obj_func, lb=lb1, ub=ub1, problem_size=prblm_size, batch_size=5,
                                                        verbose=False, epoch=50, pop_size=10)
    rpo_pos1, rpo_fit1, rpo_loss1 = rpo_.train()
    ct = time() - start  # computation time
    return ['base1', ct, rpo_pos1, rpo_fit1, rpo_loss1]


def rpo(obj_func, **kwargs):
    start = time()
    rpo_ = RPO.BaseRPO(obj_func, **kwargs)
    rpo_pos1, rpo_fit1, rpo_loss1 = rpo_.train()
    [low_bound,up_bound,overloadtask] = LoadBalancing(rpo_pos1)
    lb1 = [0]
    ub1 = [len(low_bound)]
    prblm_size = int(sum(overloadtask) if isinstance(overloadtask, (list, np.ndarray)) else 0)
    rpo_ = RPO.BaseRPO(obj_func, lb=lb1, ub=ub1, problem_size=prblm_size, batch_size=5,
                                                        verbose=False, epoch=50, pop_size=10)
    rpo_pos1, rpo_fit1, rpo_loss1 = rpo_.train()
    ct = time() - start  # computation time
    return ['rpo', ct, rpo_pos1, rpo_fit1, rpo_loss1]

def pfo(obj_func, **kwargs):
    start = time()
    rpo_ = Pufferfish.BasePFO(obj_func, **kwargs)
    rpo_pos1, rpo_fit1, rpo_loss1 = rpo_.train()
    [low_bound,up_bound,overloadtask] = LoadBalancing(rpo_pos1)
    lb1 = [0]
    ub1 = [len(low_bound)]
    prblm_size = int(sum(overloadtask) if isinstance(overloadtask, (list, np.ndarray)) else 0)
    rpo_ = Pufferfish.BasePFO(obj_func, lb=lb1, ub=ub1, problem_size=prblm_size, batch_size=5,
                                                        verbose=False, epoch=50, pop_size=10)
    rpo_pos1, rpo_fit1, rpo_loss1 = rpo_.train()
    ct = time() - start  # computation time
    return ['pfo', ct, rpo_pos1, rpo_fit1, rpo_loss1]

def loa(obj_func, **kwargs):
    start = time()
    rpo_ = lyrebird.BaseLBO(obj_func, **kwargs)
    rpo_pos1, rpo_fit1, rpo_loss1 = rpo_.train()
    [low_bound,up_bound,overloadtask] = LoadBalancing(rpo_pos1)
    lb1 = [0]
    ub1 = [len(low_bound)]
    prblm_size = int(sum(overloadtask) if isinstance(overloadtask, (list, np.ndarray)) else 0)
    rpo_ = lyrebird.BaseLBO(obj_func, lb=lb1, ub=ub1, problem_size=prblm_size, batch_size=5,
                                                        verbose=False, epoch=50, pop_size=10)
    rpo_pos1, rpo_fit1, rpo_loss1 = rpo_.train()
    ct = time() - start  # computation time
    return ['loa', ct, rpo_pos1, rpo_fit1, rpo_loss1]


def koa(obj_func, **kwargs):
    start = time()
    rpo_ = KOA.BaseKOA(obj_func, **kwargs)
    rpo_pos1, rpo_fit1, rpo_loss1 = rpo_.train()
    [low_bound,up_bound,overloadtask] = LoadBalancing(rpo_pos1)
    lb1 = [0]
    ub1 = [len(low_bound)]
    prblm_size = int(sum(overloadtask) if isinstance(overloadtask, (list, np.ndarray)) else 0)
    rpo_ = KOA.BaseKOA(obj_func, lb=lb1, ub=ub1, problem_size=prblm_size, batch_size=5,
                                                        verbose=False, epoch=50, pop_size=10)
    rpo_pos1, rpo_fit1, rpo_loss1 = rpo_.train()
    ct = time() - start  # computation time
    return ['koa', ct, rpo_pos1, rpo_fit1, rpo_loss1]

def rth(obj_func, **kwargs):
    start = time()
    rpo_ = RTH.BaseRTH(obj_func, **kwargs)
    rpo_pos1, rpo_fit1, rpo_loss1 = rpo_.train()
    [low_bound,up_bound,overloadtask] = LoadBalancing(rpo_pos1)
    lb1 = [0]
    ub1 = [len(low_bound)]
    prblm_size = int(sum(overloadtask) if isinstance(overloadtask, (list, np.ndarray)) else 0)
    rpo_ = RTH.BaseRTH(obj_func, lb=lb1, ub=ub1, problem_size=prblm_size, batch_size=5,
                                                        verbose=False, epoch=50, pop_size=10)
    rpo_pos1, rpo_fit1, rpo_loss1 = rpo_.train()
    ct = time() - start  # computation time
    return ['rth', ct, rpo_pos1, rpo_fit1, rpo_loss1]

def prop(obj_func, **kwargs):
    start = time()
    rpo_ = RTH.BaseImpRTH(obj_func, **kwargs)
    rpo_pos1, rpo_fit1, rpo_loss1 = rpo_.train()
    [low_bound,up_bound,overloadtask] = LoadBalancing(rpo_pos1)
    lb1 = [0]
    ub1 = [len(low_bound)]
    prblm_size = int(sum(overloadtask) if isinstance(overloadtask, (list, np.ndarray)) else 0)
    rpo_ = RTH.BaseImpRTH(obj_func, lb=lb1, ub=ub1, problem_size=prblm_size, batch_size=5,
                                                        verbose=False, epoch=50, pop_size=10)
    rpo_pos1, rpo_fit1, rpo_loss1 = rpo_.train()
    ct = time() - start  # computation time
    return ['prop', ct, rpo_pos1, rpo_fit1, rpo_loss1]



def multi_opt(objfun,**kwargs):
    opt = ['prop','base3','base2','base1','rpo','pfo','loa','koa','rth']
    pos, fit, loss, ct = [], [], [], []
    for Alg in opt:
        val = eval(Alg + '(objfun, **kwargs)')
        ct.append(val[1])
        pos.append(val[2])
        fit.append(val[3])
        loss.append(val[4])
    return pos, fit, loss, ct


