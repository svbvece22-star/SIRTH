#!/usr/bin/env python
# ------------------------------------------------------------------------------------------------------%
# Created by "Thieu Nguyen" at 09:49, 17/03/2020                                                        %
#                                                                                                       %
#       Email:      nguyenthieu2102@gmail.com                                                           %
#       Homepage:   https://www.researchgate.net/profile/Thieu_Nguyen6                                  %
#       Github:     https://github.com/thieu1995                                                  %
#-------------------------------------------------------------------------------------------------------%

from numpy.random import uniform, normal, randint
from numpy import pi, sin, cos, zeros, minimum, maximum, abs, where, sign
from copy import deepcopy
from optimization.root import Root
import numpy as np


class BaseLBO(Root):
    """
        The original version of: Lyrebird Optimization
    """

    def __init__(self, obj_func=None, lb=None, ub=None, problem_size=50, batch_size=10, verbose=True,
                 epoch=750, pop_size=100, c1=1.2, c2=1.2, w_min=0.4, w_max=0.9):
        Root.__init__(self, obj_func, lb, ub, problem_size, batch_size, verbose)
        self.epoch = epoch
        self.pop_size = pop_size

    def train(self):
        def hunting_strategy_exploration(X,  k):
            r = np.random.rand()
            CP = X.__len__()
            prey_index = np.random.choice(CP)
            prey_position = X[prey_index]
            #I is a random number from set {1, 2}
            I = np.random.randint(2)
            try:new_position = X[k][0] + r * (prey_position[0] - I * X[k][0])   #---------------------------------equ5
            except:1
            return new_position

        def ensure_prey_killed(X, F, k, r, t, lower_bound, upper_bound):
            new_position = X[k][0] + (1 - 2 * r) * (upper_bound[0] - lower_bound[0]) / t        # equation 7
            new_position = np.clip(new_position, lower_bound, upper_bound)
            return new_position

        pop = [self.create_solution() for _ in range(self.pop_size)] #Generate the initial population matrix
        pop = deepcopy(pop)
        g_best = self.get_global_best_solution(pop=pop, id_fit=self.ID_FIT, id_best=self.ID_MIN_PROB) # Evaluate the objective function
        # fit_new = self.get_fitness_position(pop)
        for epoch in range(self.epoch):#For t = 1 to T
            for i in range(self.pop_size):# For i = 1 to N
                rp = np.random.uniform(0, 1)
                if rp <= 0.5:
                    #Phase 1: hunting strategy (exploration)
                    x_new = hunting_strategy_exploration(pop, i)
                    x_new = self.amend_position_random_faster(x_new)
                    fit_new = self.get_fitness_position(x_new)
                    # Update current position, current velocity and compare with past position, past fitness (local best)
                    if fit_new < pop[i][self.ID_FIT]:
                        pop[i] = [x_new, fit_new]
                else:
                    #Phase2: Ensuring that the prey is killed
                    new_position_exploit = ensure_prey_killed(pop, pop[i][self.ID_FIT], i, np.random.rand(), epoch + 1, self.lb, self.ub)
                    new_position_exploit = self.amend_position_random_faster(new_position_exploit)
                    fit_new = self.get_fitness_position(new_position_exploit)

                    if fit_new < pop[i][self.ID_FIT]:
                        pop[i] = [new_position_exploit, fit_new]


                ## batch size idea
                if i % self.batch_size:
                    g_best = self.update_global_best_solution(pop, self.ID_MIN_PROB, g_best)
            self.loss_train.append(g_best[self.ID_FIT])
            if self.verbose:
                print(">Epoch: {}, Best fit: {}".format(epoch+1, g_best[self.ID_FIT]))
        self.solution = g_best
        return g_best[self.ID_POS], g_best[self.ID_FIT], self.loss_train


class HybridLBO(Root):
    """
        The original version of: Lyrebird Optimization
    """

    def __init__(self, obj_func=None, lb=None, ub=None, problem_size=50, batch_size=10, verbose=True,
                 epoch=750, pop_size=100, c1=1.2, c2=1.2, w_min=0.4, w_max=0.9):
        Root.__init__(self, obj_func, lb, ub, problem_size, batch_size, verbose)
        self.epoch = epoch
        self.pop_size = pop_size



    def train(self):
        def hunting_strategy_exploration(X,  k):
            r = np.random.rand()
            CP = X.__len__()
            prey_index = np.random.choice(CP)
            prey_position = X[prey_index]
            #I is a random number from set {1, 2}
            I = np.random.randint(2)
            new_position = X[k][0] + r * (prey_position[0] - I * X[k][0])   #---------------------------------equ6
            return new_position

        def ensure_prey_killed(X, F, k, r, t, lower_bound, upper_bound):
            new_position = X[k][0] + (1 - 2 * r) * (upper_bound[0] - lower_bound[0]) / t        # equation 7
            new_position = np.clip(new_position, lower_bound, upper_bound)
            return new_position

        pop = [self.create_solution() for _ in range(self.pop_size)] #Generate the initial population matrix
        pop = deepcopy(pop)
        g_best = self.get_global_best_solution(pop=pop, id_fit=self.ID_FIT, id_best=self.ID_MIN_PROB) # Evaluate the objective function
        # fit_new = self.get_fitness_position(pop)
        for epoch in range(self.epoch):#For t = 1 to T
            for i in range(self.pop_size):# For i = 1 to N
                rp = np.random.uniform(0, 1)
                if rp <= 0.5:
                    #Phase 1: hunting strategy (exploration)
                    # Improvement
                    iguana = g_best[self.ID_POS]
                    I = round(1 + uniform())
                    X_P1 = pop[i][self.ID_POS] + uniform() * (iguana - I * pop[i][self.ID_POS])  # Eq.(4)
                    pop[i][ self.ID_POS] = (X_P1 - uniform() * iguana) / (1 - uniform() * I)

                    X = pop.copy()
                    k = i
                    r = np.random.rand()
                    CP = X.__len__()
                    prey_index = np.random.choice(CP)
                    prey_position = X[prey_index]
                    # I is a random number from set {1, 2}
                    I = np.random.randint(2)
                    x_new = ((r * prey_position[0] - uniform() * iguana/(1 - uniform() * iguana)) + (r * I * uniform() * iguana)/(1 - uniform() * iguana)) / (1 - (1 / (1 - uniform() * iguana)) + (r * I) / (1 - uniform() * iguana))
                    # x_new = X[k][0] + r * (
                    #             prey_position[0] - I * X[k][0])  # ---------------------------------equ6

                    # x_new = hunting_strategy_exploration(pop, i)
                    x_new = self.amend_position_random_faster(x_new)
                    fit_new = self.get_fitness_position(x_new)
                    # Update current position, current velocity and compare with past position, past fitness (local best)
                    if fit_new < pop[i][self.ID_FIT]:
                        pop[i] = [x_new, fit_new]
                else:
                    #Phase2: Ensuring that the prey is killed
                    new_position_exploit = ensure_prey_killed(pop, pop[i][self.ID_FIT], i, np.random.rand(), epoch + 1, self.lb, self.ub)
                    fit_new = self.get_fitness_position(new_position_exploit)

                    if fit_new < pop[i][self.ID_FIT]:
                        pop[i] = [new_position_exploit, fit_new]


                ## batch size idea
                if i % self.batch_size:
                    g_best = self.update_global_best_solution(pop, self.ID_MIN_PROB, g_best)
            self.loss_train.append(g_best[self.ID_FIT])
            if self.verbose:
                print(">Epoch: {}, Best fit: {}".format(epoch+1, g_best[self.ID_FIT]))
        self.solution = g_best
        return g_best[self.ID_POS], g_best[self.ID_FIT], self.loss_train