import cv2
from tensorflow.keras import layers, models
from tensorflow.keras.utils import to_categorical
from tensorflow.python.keras.layers import Concatenate
from tensorflow.python.layers.normalization import BatchNormalization
from tensorflow.python.layers.pooling import AveragePooling2D
from torchvision.models.resnet import conv3x3

from other.norm_ import *

def LeNet_(x_train, y_train, x_test, Y_test,ep=None):
    print("LeNet Model")
    ln = len(set(y_train.flatten()))
    x_train = reshape__(x_train)
    x_test = reshape__(x_test)
    input_shape_ = (32, 32, 1)
    y_train = to_categorical(y_train)
    y_test = to_categorical(Y_test)
    # Build the LeNet-5 model
    model = models.Sequential()
    # define the first set of CONV => ACTIVATION => POOL layers

    model.add(layers.Conv2D(16, (5, 5), activation='relu', input_shape=input_shape_))
    model.add(layers.MaxPooling2D((2, 2)))
    # define the second set of CONV => ACTIVATION => POOL layers
    model.add(layers.Conv2D(32, (5, 5), activation='relu'))
    model.add(layers.MaxPooling2D((2, 2)))
    # define the first FC => ACTIVATION layers
    model.add(layers.Flatten())
    model.add(layers.Dense(120, activation='relu'))
    model.add(layers.Dense(84, activation='relu'))
    # define the second FC layer
    model.add(layers.Dense(1, activation='linear'))

    # Compile the model
    model.compile(optimizer='adam',
                  loss='mean_squared_error',
                  metrics=['mean_absolute_error'])
    # Train the model
    model.fit(x_train, y_train, epochs=ep, batch_size=64, validation_split=0.2, verbose=0)
    y_predict = array(np.argmax(model.predict(x_test), axis=1), axis=0)
    return y_predict


def reshape__(data):
    # Convert the data to the appropriate data type (e.g., uint8)
    data_uint8 = (data * 255).astype(np.uint8)
    # Reshape and resize the data
    resized_data = np.zeros((len(data), 32, 32, 1), dtype=np.uint8)
    for i in range(len(data_uint8)):
        img = data_uint8[i].reshape(1, data_uint8.shape[1])  # Reshape each feature for processing
        img_resized = cv2.resize(img, (32, 32))  # Resize the feature to the desired shape
        img_resized_3d = np.repeat(img_resized[:, :, np.newaxis], 1, axis=2)  # Convert to  channels
        resized_data[i] = img_resized_3d  # Assign the resized image to the corresponding index in the new array
    return resized_data


import tensorflow as tf
from tensorflow.keras.layers import Layer
import numpy as np
from tensorflow.keras import layers, models
from tensorflow.keras.layers import Conv2D, BatchNormalization, AveragePooling2D, UpSampling2D, Concatenate, Dropout, \
    Flatten, Dense, LeakyReLU
from tensorflow.keras.utils import to_categorical
import tensorflow as tf
from tensorflow.keras import layers


class ResidualBlock(layers.Layer):
    def __init__(self, filters, kernel_size):
        super(ResidualBlock, self).__init__()
        self.conv1 = layers.Conv2D(filters, kernel_size, padding='same')
        self.bn1 = layers.BatchNormalization()
        self.swish = layers.Activation('swish')
        self.conv2 = layers.Conv2D(filters, kernel_size, padding='same')
        self.bn2 = layers.BatchNormalization()
        self.hard_elish = layers.Activation('hard_sigmoid')
        self.match_dimensions = layers.Conv2D(filters, kernel_size=1, padding='same')  # To match dimensions

    def call(self, x):
        residual = x

        # Apply first convolution and batch normalization
        out = self.conv1(x)
        out = self.bn1(out)
        out = self.swish(out)

        # Apply second convolution and batch normalization
        out = self.conv2(out)
        out = self.bn2(out)
        out = self.hard_elish(out)

        # Match dimensions
        residual = self.match_dimensions(residual)

        # Add residual to output
        out += residual
        return out

# Define the spatial pyramid pooling layer
class SpatialPyramidPooling2D(Layer):
    def __init__(self, pool_sizes, **kwargs):
        super(SpatialPyramidPooling2D, self).__init__(**kwargs)
        self.pool_sizes = pool_sizes

    def call(self, inputs):
        pooled_outputs = []
        for pool_size in self.pool_sizes:
            pooled = AveragePooling2D(pool_size=pool_size, strides=1, padding='same')(inputs)
            pooled_outputs.append(Flatten()(pooled))
        return Concatenate()(pooled_outputs)

# Custom loss function
def custom_loss(y_true, y_pred):
    p = tf.reduce_sum(y_true)
    p_prime = tf.reduce_sum(y_pred)
    beta = 0.5  # You can adjust beta
    term1 = p_prime / (p_prime + beta * (1 - p) * p_prime + (1 - beta) * p * (1 - p_prime))
    term2 = tf.cosh(1 - ((2 * p_prime + 1) / (p + p_prime + 1)))
    term3 = 2 * np.pi * tf.exp(-0.5 * (p_prime / p + p_prime))
    return term1 + term2 + term3

import numpy as np
def impLeNet_(x_train, y_train, x_test, Y_test):
    print("LeNet Model with New Architecture")

    ln = len(set(y_train.flatten()))
    x_train = reshape__(x_train)
    x_test = reshape__(x_test)
    input_shape_ = (32, 32, 1)
    y_train = to_categorical(y_train)
    y_test = to_categorical(Y_test)

    # Define inputs
    input_tensor = layers.Input(shape=input_shape_)

    # Initial Conv Layer
    x = Conv2D(16, (5, 5), padding='same')(input_tensor)
    x = BatchNormalization()(x)
    x = AveragePooling2D(pool_size=(2, 2))(x)

    # Parallel Convolution Layers
    conv1 = Conv2D(32, (3, 3), padding='same')(x)
    bn1 = BatchNormalization()(conv1)
    mixed_pooling = AveragePooling2D(pool_size=2, strides=2, padding='same')(bn1)

    conv2 = Conv2D(32, (3, 3), padding='same')(x)
    bn2 = BatchNormalization()(conv2)
    leaky_relu = LeakyReLU()(bn2)

    # Upsample mixed_pooling to match leaky_relu
    mixed_pooling_upsampled = UpSampling2D(size=(2, 2))(mixed_pooling)

    # Concatenate along the last axis
    concatenated = Concatenate(axis=-1)([mixed_pooling_upsampled, leaky_relu])

    # Apply Residual Block
    residual_block = ResidualBlock(64, (3, 3))(concatenated)

    # Apply Spatial Pyramid Pooling
    spp = SpatialPyramidPooling2D(pool_sizes=[1, 2, 4])(residual_block)

    # Apply Dropout
    x = Dropout(0.5)(spp)

    # Flatten and add Fully Connected Layers
    x = Flatten()(x)
    x = Dense(120, activation='relu')(x)
    x = Dense(84, activation='relu')(x)
    output_tensor = Dense(ln, activation='softmax')(x)

    # Create the model
    model = models.Model(inputs=input_tensor, outputs=output_tensor)

    # Compile the model
    model.compile(optimizer='adam',
                  loss='categorical_crossentropy',  # Change if you have a custom loss
                  metrics=['accuracy'])

    # Train the model
    model.fit(x_train, y_train, epochs=10, batch_size=64, validation_split=0.2, verbose=1)  # Adjust epochs as needed

    # Predict
    y_predict = np.argmax(model.predict(x_test), axis=1)

    return y_predict
