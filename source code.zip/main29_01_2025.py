
import os
import argparse
import ar as ar
from sklearn.model_selection import train_test_split
from FCM import FCM
from optimization.optim_main import multi_opt
import Cloudsim.Run
from colorama import Fore, init
from numpy import array as ar
import pandas as pd
import math
from tensorflow.python.keras.models import Sequential, load_model
from tensorflow.python.keras.layers import   Conv1D, MaxPooling1D, Dropout, Flatten,  Dense
from sklearn.metrics import mean_absolute_error, mean_squared_log_error, \
    median_absolute_error
from sklearn.metrics import mean_squared_error as mse
from pytictoc import TicToc
from other.norm_ import *
from other.norm_ import normalize, array
from other import popup, result
from matplotlib import pyplot as plt
from Cloudsim import cloud_parameters
import warnings

fullAnalysis = True

if fullAnalysis == True:

    def ReadDataset(PARAM):
        run = True
        if run:
            # Ensure the target directory exists
            data = np.array(PARAM['input_para'])
            tar = np.array(PARAM['CPU usage'])
            os.makedirs('pre_evaluated', exist_ok=True)
            # Save the data and target arrays with dtype=object
            np.save(f'pre_evaluated/Data.npy', np.array(data, dtype=object))
            np.save(f'pre_evaluated/Tar.npy', np.array(tar, dtype=object))
            vm_capacity = PARAM['vm_capacity']
            np.save(f'pre_evaluated/vm_capacity.npy', np.array(vm_capacity, dtype=object))
            return data, tar
        else:
           data = np.load(f'pre_evaluated/Data.npy', allow_pickle=True)
           tar = np.load(f'pre_evaluated/Tar.npy', allow_pickle=True)
           return data, tar

    # Step 1: Convert `clu_data` to a clean numeric NumPy array
    def clean_data(data):
        """Convert array to float and handle non-numeric values."""
        data = np.array(data[0], dtype=str)  # Ensure all elements are strings
        data = np.char.strip(data)  # Remove extra spaces
        data = np.where(data == '', 'nan', data)  # Replace empty strings with NaN
        data = np.where(data == 'None', 'nan', data)  # Handle 'None' strings
        try:
            data = np.array(data, dtype=np.float64)  # Convert to float
        except ValueError:
            raise ValueError("Data contains non-numeric values that couldn't be converted.")

        return data

    def  Numerical_saaty_preferences(t, p):
        """
        Determines Saaty preference based on two values.
        Parameters:
            t (float): First value
            p (float): Second value
        Returns:
            float: Saaty preference value (1 to 9 or reciprocal values for lower preference)
        k = list(np.arange(np.min(run_time), np.max(run_time), 40000000))
        """
        diff = abs(t - p)  # Store the absolute difference for efficiency
        if diff == 0:
            return 1  # Equally preferred
        elif 1_000_000 <= diff < 41_000_000:
            return 2 if t > p else 1 / 2
        elif 41_000_000 <= diff < 81_000_000:
            return 3 if t > p else 1 / 3
        elif 81_000_000 <= diff < 121_000_000:
            return 4 if t > p else 1 / 4
        elif 121_000_000 <= diff < 161_000_000:
            return 5 if t > p else 1 / 5
        elif 161_000_000 <= diff < 201_000_000:
            return 6 if t > p else 1 / 6
        elif 201_000_000 <= diff < 241_000_000:
            return 7 if t > p else 1 / 7
        elif 241_000_000 <= diff < 281_000_000:
            return 8 if t > p else 1 / 8
        elif 281_000_000 <= diff <= 300_000_000:
            return 9 if t > p else 1 / 9

    def sort_with_index(numbers):
        sorted_with_index = sorted(enumerate(numbers), key=lambda x: x[1])  # Sort by value
        ids, vals = zip(*sorted_with_index)  # Unpack into separate lists
        return list(ids), list(vals)

    def testobjfun(sol):
        APHRank = np.load(f'pre_evaluated/APHRank.npy', allow_pickle=True)
        if len(sol) < 400:
            APHRank = APHRank[0:len(sol)]
        fcm_data = np.load(f'pre_evaluated/clustering_idx.npy', allow_pickle=True)
        task_runtime = np.load(f'pre_evaluated/task_runtime.npy', allow_pickle=True)
        w1, w2, w3, w4 = 0.25, 0.25, 0.25, 0.25
        soln = np.round(sol)
        ## ranking
        rankidx = np.zeros((len(sol), 2))
        uni = np.unique(soln)
        for i in range(0, len(uni)):
            task_count = np.where(soln == uni[i])  # task count in i th VM
            for j in range(0, len(task_count[0])):
                rankidx[task_count[0][j], 0] = APHRank[task_count[0][j]]
                rankidx[task_count[0][j], 1] = soln[task_count[0][j]]
        ids, vals = sort_with_index(rankidx[:, 0])
        new_soln = rankidx[ids, 1]

        ## clustering
        VMidx = np.zeros((len(sol), 2))
        for i in range(0, len(sol)):
            search_value = new_soln[i]
            for index, inner_list in enumerate(fcm_data):
                if search_value in inner_list:
                    VMidx[i, 0] = search_value
                    VMidx[i, 1] = index

        indices = new_soln.astype(int)  # Convert all elements of new_soln to integers
        task_runtime[indices]  # Now you can use the integer indices to index task_runtime
        cluster_runtime = []
        for i in range(0, 5):
            task_count_ = np.where(VMidx[:, 1] == i)
            cluster_runtime.append(task_runtime[task_count_[
                0]] / 1000000000)  ### convert microseconds into sseconds 1 sec = 1x10^6 microsec
        ## Makespan
        CTime = []
        for i in range(0, 5):
            CTime.append(np.sum(cluster_runtime[i]))
        ms = np.max(CTime)

        ## Resource Utilization
        VM = len(uni)
        ru = np.sum(CTime) / (ms * VM)
        ## Execution time
        et = np.sum(CTime)
        ## Degree of Imbalance
        dt = []
        for i in range(0, 5):
            T = cluster_runtime[i]
            if len(T) > 0:
                Tmax = np.max(T)
                Tmin = np.min(T)
                Tavg = np.mean(T)
                Tdt = (Tmax - Tmin) / Tavg
            else:
                Tdt = 0
            dt.append(Tdt)
        di = np.mean(dt)
        return ms,di,ru,et

    def objfun(sol):
        APHRank = np.load(f'pre_evaluated/APHRank.npy', allow_pickle=True)
        if len(sol)<400:
            APHRank = APHRank[0:len(sol)]
        fcm_data = np.load(f'pre_evaluated/clustering_idx.npy', allow_pickle=True)
        task_runtime = np.load(f'pre_evaluated/task_runtime.npy', allow_pickle=True)

        w1, w2, w3, w4 = 0.25, 0.25, 0.25, 0.25
        soln = np.round(sol)
        ## ranking
        rankidx = np.zeros((len(sol), 2))
        uni = np.unique(soln)
        for i in range(0, len(uni)):
            task_count = np.where(soln == uni[i])  # task count in i th VM
            for j in range(0, len(task_count[0])):
                rankidx[task_count[0][j], 0] = APHRank[task_count[0][j]]
                rankidx[task_count[0][j], 1] = soln[task_count[0][j]]
        ids, vals = sort_with_index(rankidx[:,0])
        new_soln = rankidx[ids,1]

        ## clustering
        VMidx = np.zeros((len(sol),2))
        for i in range(0,len(sol)):
            search_value = new_soln[i]
            for index, inner_list in enumerate(fcm_data):
                if search_value in inner_list:
                    VMidx[i,0] = search_value
                    VMidx[i,1] = index

        indices = new_soln.astype(int)  # Convert all elements of new_soln to integers
        task_runtime[indices]  # Now you can use the integer indices to index task_runtime
        cluster_runtime = []
        for i in range(0,5):
            task_count_ = np.where(VMidx[:, 1] == i)
            cluster_runtime.append(task_runtime[task_count_[0]]/1000000000) ### convert microseconds into sseconds 1 sec = 1x10^6 microsec
        ## Makespan
        CTime = []
        for i in range(0,5):
            CTime.append(np.sum(cluster_runtime[i]))
        ms = np.max(CTime)

        ## Resource Utilization
        VM = len(uni)
        ru = np.sum(CTime)/(ms * VM)
        ## Execution time
        et = np.sum(CTime)
        ## Degree of Imbalance
        dt = []
        for i in range(0,5):
            T = cluster_runtime[i]
            if len(T) > 0:
                Tmax = np.max(T)
                Tmin = np.min(T)
                Tavg = np.mean(T)
                Tdt = (Tmax - Tmin) / Tavg
            else:
                Tdt =  0
            dt.append(Tdt)
        di = np.mean(dt)
        fit = (w1 * ms) + (w2 * di) + (w3 * ru) + (w4 * et)
        return fit

    def impLnet():
        t = TicToc()
        t.tic()
        from impLinkNet import implinknet
        predict = implinknet(X_train, Y_train, X_test, Y_test)
        predict =predict.reshape(-1, 1)
        MSE = mse(Y_test.reshape(-1, 1), predict)
        RMSE = math.sqrt(MSE)
        MAE = mean_absolute_error(Y_test.reshape(-1, 1), predict)
        MSLE = mean_squared_log_error(Y_test.reshape(-1, 1), predict.__abs__())
        MEAE = median_absolute_error(Y_test.reshape(-1, 1), predict)
        MedAE = median_absolute_error(Y_test.reshape(-1, 1), predict)
        t.toc()
        return [MSE, RMSE, MAE, MSLE, MEAE,MedAE], predict, t.tocvalue()

    def dcnn():
        t = TicToc()
        t.tic()
        unique_name = f'net_saved/dcnn'  # Python equivalent of num2str(k)
        reget_flag = 0
        # Directory to save the network
        sav_folder = 'net_saved'
        if not os.path.exists(sav_folder):
            os.makedirs(sav_folder)
        # Name of the file to save the model
        sav_name = f'net_saved/dcnn.h5'
        # Check if the file exists or if reget_flag is set to 1
        if not os.path.exists(os.path.join(sav_name)) or reget_flag == 1:
            cnn_X_test = X_test.reshape(-1, 1, X_test.shape[1])
            cnn_X_train = X_train.reshape(-1, 1, X_train.shape[1])
            cnn_X_train = cnn_X_train.astype(np.float32)
            cnn_X_test = cnn_X_test.astype(np.float32)
            model = Sequential()
            model.add(Conv1D(32, (1,), padding='valid', input_shape=cnn_X_train[0].shape, activation='relu'))
            model.add(MaxPooling1D(pool_size=(1,)))
            model.add(Conv1D(32, (1,), padding='valid', activation='relu'))
            model.add(MaxPooling1D(pool_size=(1,)))
            model.add(Conv1D(32, (1,), padding='valid', activation='relu'))
            model.add(MaxPooling1D(pool_size=(1,)))
            model.add(Conv1D(32, (1,), padding='valid', activation='relu'))
            model.add(MaxPooling1D(pool_size=(1,)))
            model.add(Conv1D(32, (1,), padding='valid', activation='relu'))
            model.add(MaxPooling1D(pool_size=(1,)))
            model.add(Conv1D(32, (1,), padding='valid', activation='relu'))
            model.add(MaxPooling1D(pool_size=(1,)))
            model.add(Dropout(0.2))
            model.add(Flatten())
            model.add(Dense(1, activation='linear'))
            model.compile(loss='mean_squared_error', optimizer='sgd', metrics=['mean_absolute_error'])
            model.fit(cnn_X_train, Y_train.astype(np.float32), epochs=1, batch_size=50, verbose=0)
            predict = array(model.predict(cnn_X_test), axis=0)
            model.summary()
            model.save(sav_name)
        else:
            cnn_X_test = X_test.reshape(-1, 1, X_test.shape[1])
            cnn_X_test = cnn_X_test.astype(np.float32)
            model = load_model(sav_name)
            predict = array(model.predict(cnn_X_test), axis=0)
        MSE = mse(Y_test.reshape(-1, 1), predict)
        RMSE = math.sqrt(MSE)
        MAE = mean_absolute_error(Y_test.reshape(-1, 1), predict)
        MSLE = mean_squared_log_error(Y_test.reshape(-1, 1), predict.__abs__())
        MEAE = median_absolute_error(Y_test.reshape(-1, 1), predict)
        MedAE = median_absolute_error(Y_test.reshape(-1, 1), predict)
        predict = predict.reshape(-1, 1)
        t.toc()
        return [MSE, RMSE, MAE, MSLE, MEAE,MedAE], predict, t.tocvalue()

    def Lnet():
        t = TicToc()
        t.tic()
        from LinkNet import linknet
        predict = linknet(X_train, Y_train, X_test, Y_test)
        predict =predict.reshape(-1, 1)
        MSE = mse(Y_test.reshape(-1, 1), predict)
        RMSE = math.sqrt(MSE)
        MAE = mean_absolute_error(Y_test.reshape(-1, 1), predict)
        MSLE = mean_squared_log_error(Y_test.reshape(-1, 1), predict.__abs__())
        MEAE = median_absolute_error(Y_test.reshape(-1, 1), predict)
        MedAE = median_absolute_error(Y_test.reshape(-1, 1), predict)
        t.toc()
        return [MSE, RMSE, MAE, MSLE, MEAE,MedAE], predict, t.tocvalue()

    def Lenet():
        t = TicToc()
        t.tic()
        from LeNet import LeNet_
        predict = LeNet_(X_train, Y_train, X_test, Y_test).reshape(-1, 1)
        predict = predict.reshape(-1, 1)
        MSE = mse(Y_test.reshape(-1, 1), predict)
        RMSE = math.sqrt(MSE)
        MAE = mean_absolute_error(Y_test.reshape(-1, 1), predict)
        MSLE = mean_squared_log_error(Y_test.reshape(-1, 1), predict.__abs__())
        MEAE = median_absolute_error(Y_test.reshape(-1, 1), predict)
        MedAE = median_absolute_error(Y_test.reshape(-1, 1), predict)
        t.toc()
        return [MSE, RMSE, MAE, MSLE, MEAE,MedAE], predict, t.tocvalue()

    def Snet():
        t = TicToc()
        t.tic()
        from Squeezenet import squeezenet
        predict = squeezenet(X_train, Y_train, X_test, Y_test)
        MSE = mse(Y_test.reshape(-1, 1), predict)
        RMSE = math.sqrt(MSE)
        MAE = mean_absolute_error(Y_test.reshape(-1, 1), predict)
        MSLE = mean_squared_log_error(Y_test.reshape(-1, 1), predict.__abs__())
        MEAE = median_absolute_error(Y_test.reshape(-1, 1), predict)
        MedAE = median_absolute_error(Y_test.reshape(-1, 1), predict)
        predict = predict.reshape(-1, 1)
        t.toc()
        return [MSE, RMSE, MAE, MSLE, MEAE,MedAE], predict, t.tocvalue()

    def Enet():
        t = TicToc()
        t.tic()
        from EfficientNet import efficient_net
        predict = efficient_net(X_train, Y_train, X_test, Y_test)
        MSE = mse(Y_test.reshape(-1, 1), predict)
        RMSE = math.sqrt(MSE)
        MAE = mean_absolute_error(Y_test.reshape(-1, 1), predict)
        MSLE = mean_squared_log_error(Y_test.reshape(-1, 1), predict.__abs__())
        MEAE = median_absolute_error(Y_test.reshape(-1, 1), predict)
        MedAE = median_absolute_error(Y_test.reshape(-1, 1), predict)
        predict = predict.reshape(-1, 1)
        t.toc()
        return [MSE, RMSE, MAE, MSLE, MEAE,MedAE], predict, t.tocvalue()

    def stat_analysis1(xx):
        xx = np.array(xx, dtype=float)  # Ensure input is a float array
        mn = np.mean(xx, axis=0)
        mdn = np.median(xx, axis=0)
        std_dev = np.std(xx, axis=0)
        min_val = np.min(xx, axis=0)
        max_val = np.max(xx, axis=0)
        return np.vstack((mn, mdn, std_dev, min_val, max_val))

    def stat_analysis(xx):
        mn = np.mean(xx, axis=0).reshape(-1, 1)
        mdn = np.median(xx, axis=0).reshape(-1, 1)
        std_dev = np.std(xx, axis=0).reshape(-1, 1)
        min = np.min(xx, axis=0).reshape(-1, 1)
        mx = np.max(xx, axis=0).reshape(-1, 1)
        return np.concatenate((mn, mdn, std_dev, min, mx), axis=1)

    def bar_plot(X, clr=None, index=None,hatches = None, xlabel=None, ylable=None):
        br1 = np.arange(4)
        # plt.style.use('grayscale')
        plt.figure(figsize=(12, 7))
        plt.rc('font', weight='bold')
        for i in range(X.shape[1]):
            plt.bar(br1, X[:, i], color=clr[i], width=0.085,
                    edgecolor='k', label=index[i],hatch=hatches[i])
            br1 = [x + 0.085 for x in br1]
        plt.subplots_adjust(bottom=0.2)
        plt.legend(loc='lower center', bbox_to_anchor=(0.5, -0.3), fontsize=15, ncol=5)
        plt.xlabel(xlabel,  weight='bold', size=16)
        plt.ylabel(ylable,  weight='bold', size=16)
        plt.xticks([r+0.3 for r in range(4)],
                   ['60', '70', '80', '90'],  weight='bold', size=14)
        plt.yticks(weight='bold', size=14)
        plt.savefig(f'Results/fullanalysis/ {ylable}(load prediction).png', dpi=800)

    def bar_plot1(X, mm, clr=None, index=None, hatches=None, xlabel=None, ylable=None):
        [n, m] = np.shape(X)
        br1 = np.arange(n)
        # plt.style.use('grayscale')
        plt.figure(figsize=(12, 7))
        plt.rc('font', weight='bold')
        for i in range(X.shape[1]):
            plt.bar(br1, X[:, i], color=clr[i], width=0.085,
                    edgecolor='k', label=index[i], hatch=hatches[i])
            br1 = [x + 0.085 for x in br1]
        plt.subplots_adjust(bottom=0.2)
        plt.legend(loc='lower center', bbox_to_anchor=(0.5, -0.3), fontsize=15, ncol=5)
        plt.xlabel(xlabel, weight='bold', size=16)
        plt.ylabel(ylable, weight='bold', size=16)
        if mm == 1:
            plt.xticks([r + 0.3 for r in range(n)],
                   ['100', '200', '300', '400'], weight='bold', size=12)
            plt.yticks(weight='bold', size=14)
            plt.savefig(f'Results/fullanalysis/Task Variation vs {ylable}.png', dpi=800)
        elif mm == 2:
            plt.xticks([r + 0.3 for r in range(n)],
                   ['10', '20', '30', '40','50'], weight='bold', size=12)
            plt.yticks(weight='bold', size=14)
            plt.savefig(f'Results/fullanalysis/VM Variation vs {ylable}.png', dpi=800)

    def line_graph(X, n, clr=None, index=None, xlabel=None, ylable=None):
        # markers = ['<', 'o', '|', 'P', 's', 'D', '^', 'v', '*']
        plt.figure(figsize=(12, 7))
        plt.rc('font', weight='bold')
        for i in range(X.shape[0]):
            plt.plot(X[i, :], color=clr[i], label=index[i],
                     linestyle='-', linewidth=3, zorder=3)
        plt.subplots_adjust(bottom=0.2)
        plt.grid(color='g', linestyle=':', linewidth=0.9)
        plt.legend(loc='lower center', bbox_to_anchor=(0.5, -0.3), fontsize=12, ncol=5)
        plt.xlabel(xlabel, weight='bold', size=16)
        plt.ylabel(ylable, weight='bold', size=16)
        plt.yticks(weight='bold', size=14)
        plt.xticks(weight='bold', size=14)
        if n==1:
            plt.savefig(f'Results/fullanalysis/Task variation_convergence.png', dpi=800)
        elif n==2:
            plt.savefig(f'Results/fullanalysis/VM variation_convergence.png', dpi=800)

    def cloud_initialize():
        print("\nInitializing VM For Cloud..")
        PARAM = Cloudsim.Run.cloud_sim()
        print("\nGenerating VM parameters...")
        return PARAM



    ## using cloud sim
    PARAM = cloud_initialize()
    ##  Load prediction using Linknet
    Load_prediction = False
    if Load_prediction:
        [Data, Tar] = ReadDataset(PARAM)
        ### train impLimknet
        from impLinkNet import implinknet
        lp=1
        X_train = Data
        Y_train = Tar
        X_test =  Data
        Y_test = Tar
        X_train = X_train/np.max(X_train)
        Y_train = Y_train / np.max(Y_train)
        X_test = X_test/np.max(X_test)
        Y_test = Y_test / np.max(Y_test)
        y_pred = implinknet(X_train, Y_train, X_test, Y_test, lp)
        np.save(f'pre_evaluated/utilizeVM.npy', np.array(y_pred, dtype=object))
    else:
        utilizeVM = np.load(f'pre_evaluated/saved/utilizeVM.npy', allow_pickle=True)


    ## Clustering of VM
    Clustering_VM = False
    if Clustering_VM:
        ## step1:::Ranking of task using modified AHP(Analytic Hierachy process)
        run_time = np.array(PARAM['run_time'])
        np.save(f'pre_evaluated/task_runtime.npy', np.array(run_time, dtype=object))

        task_capacity = PARAM['task_capacity']
        np.save(f'pre_evaluated/task_capacity.npy', np.array(task_capacity, dtype=object))

        ## AHP(Analytic Hierachy process)
        #  Table 2
        new_run_time =np.zeros((400,400))#np.zeros((4000,4000))
        for i in range(0,400):# 4000
            for j in range(0, 400):
                new_run_time[i, j] = Numerical_saaty_preferences(run_time[i], run_time[j])
        # Table 3 Summation of each column
        column_sums = np.sum(new_run_time, axis=0)
        # Table 5 Normalization of column value
        nor_new_run_time = np.zeros_like(new_run_time)
        nor_new_run_time = new_run_time / column_sums
        # Table 7 Summation of each column
        nor_column_sums = np.sum(nor_new_run_time, axis=0)
        # Table 8 Compute weighted sum
        nor_average =  np.mean(nor_new_run_time, axis=1)
        ids, vals = sort_with_index(nor_average)
        print("Sorted Indices:", ids)
        print("Sorted Values:", vals)
        np.save(f'pre_evaluated/APHRank.npy', np.array(ids, dtype=object))

        ## step2::: KFCM used for clustering the VM(kernal fuzzy means clustering)
        # Reshape `tar` to have the same number of columns as `data` (i.e., 9 columns)
        utilizeVM_reshaped = utilizeVM.reshape(-1, 1)  # This reshapes tar to (100000, 1)
        # Concatenate data and tar
        clu_data = np.zeros((50, 10))  #
        clu_data[:, 0:9] = Data[np.arange(0, 100000, 2000) + 1999, :]
        clu_data[:, 9] = utilizeVM[np.arange(0, 100000, 2000) + 1999]
        clu_data = clean_data([clu_data[:, 1:9]])
        centers = None
        # Step 2: Check for and replace NaN values
        if np.isnan(clu_data).sum() > 0:
            print(f"Found {np.isnan(clu_data).sum()} NaN values, replacing them...")
            col_means = np.nanmean(clu_data, axis=0)  # Compute column means
            inds = np.where(np.isnan(clu_data))  # Find NaN indices
            clu_data[inds] = np.take(col_means, inds[1])  # Replace NaNs with column means
        # Step 3: Ensure `centers` is also numeric (if applicable)
        try:
            centers = np.array(centers, dtype=np.float64)
        except NameError:
            print("Warning: `centers` is not defined. Make sure it's available before running FCM.")

        # Step 4: Fit the Fuzzy C-Means model
        fcm = FCM(n_clusters=5)  # Adjust cluster count as needed
        fcm.fit(clu_data)
        # Predicted cluster centers
        fcm_centers = fcm.centers
        # Predicted cluster membership
        fcm_labels = fcm.predict(clu_data)
        ## Cluster data based on fcm clustering
        a = np.where(fcm_labels == 0)
        a1 = np.where(fcm_labels == 1)
        a2 = np.where(fcm_labels == 2)
        a3 = np.where(fcm_labels == 3)
        a4 = np.where(fcm_labels == 4)

        fcm_dataa = [a[0], a1[0], a2[0], a3[0], a4[0]]
        np.save(f'pre_evaluated/clustering_idx.npy', np.array(fcm_dataa, dtype=object))
    else:
        APHRank = np.load(f'pre_evaluated/APHRank.npy', allow_pickle=True)
        fcm_data = np.load(f'pre_evaluated/clustering_idx.npy', allow_pickle=True)

    ## Optimal Task Scheduling
    Optimal_Task_Scheduling = True
    if Optimal_Task_Scheduling:
        ## Virtual Machine variation
        vm = PARAM['no_vm']
        makespan = np.zeros((len(vm),8))
        Deg_imbalance  = np.zeros((len(vm),8))
        res_utili = np.zeros((len(vm),8))
        Exe_time  = np.zeros((len(vm),8))
        CT , Loss , Fit =[],[],[]
        print('Optimization')
        VM_capacity = PARAM['vm_capacity']
        for i in range(0,len(vm)):
            lb = [0]
            ub = [int(vm[i])]
            capacity = VM_capacity[i]
            np.save(f'pre_evaluated/Capacity.npy', np.array(capacity, dtype=object))
            an = 1
            if an == 1: pos, fit, loss, ct = multi_opt(objfun, lb=lb, ub=ub, problem_size=400, batch_size=5,
                                                        verbose=False, epoch=50, pop_size=10)

            CT.append(ct)
            Loss.append(loss)
            Fit.append(fit)
            for idx, p in enumerate(pos):
                ms,di,ru,et = testobjfun(p)
                makespan[i,idx] = ms
                Deg_imbalance[i,idx] = di
                res_utili[i,idx] = ru
                Exe_time[i,idx] = et

        np.save(f'pre_evaluated/VM_makespan.npy', extracts(np.array(makespan, dtype=object),axis=1))
        np.save(f'pre_evaluated/VM_Deg_imbalance.npy', extracts(np.array(Deg_imbalance, dtype=object),axis=1))
        np.save(f'pre_evaluated/VM_res_utili.npy', extracts(np.array(res_utili, dtype=object),axis=1))
        np.save(f'pre_evaluated/VM_Exe_time.npy', extracts(np.array(Exe_time, dtype=object),axis=1))
        np.save(f'pre_evaluated/VM_Time.npy', extracts(np.array(CT, dtype=object),axis=1))
        np.save(f'pre_evaluated/VM_Loss.npy', np.array(Loss, dtype=object))
        np.save(f'pre_evaluated/VM_Fit.npy', extracts(np.array(Fit, dtype=object),axis=1))

        ## Task Variation
        Task = PARAM['no_task']
        makespan = np.zeros((len(Task), 8))
        Deg_imbalance = np.zeros((len(Task), 8))
        res_utili = np.zeros((len(Task), 8))
        Exe_time = np.zeros((len(Task), 8))
        CT, Loss, Fit = [], [], []
        print('Optimization')
        task_capacity = PARAM['task_capacity']
        for i in range(0, len(Task)):
            lb = [0]
            ub = [49]
            capacity = task_capacity[i]
            np.save(f'pre_evaluated/Capacity.npy', np.array(capacity, dtype=object))
            an = 1
            if an == 1: pos, fit, loss, ct = multi_opt(objfun, lb=lb, ub=ub, problem_size=Task[i], batch_size=5,
                                                        verbose=False, epoch=50, pop_size=10)
            CT.append(ct)
            Loss.append(loss)
            Fit.append(fit)
            for idx, p in enumerate(pos):
                ms,di,ru,et = testobjfun(p)
                makespan[i,idx] = ms
                Deg_imbalance[i,idx] = di
                res_utili[i,idx] = ru
                Exe_time[i,idx] = et

        np.save(f'pre_evaluated/Task_makespan.npy', extracts(np.array(makespan, dtype=object),axis=0))
        np.save(f'pre_evaluated/Task_Deg_imbalance.npy', extracts(np.array(Deg_imbalance, dtype=object),axis=0))
        np.save(f'pre_evaluated/Task_res_utili.npy', extracts(np.array(res_utili, dtype=object),axis=0))
        np.save(f'pre_evaluated/Task_Exe_time.npy', extracts(np.array(Exe_time, dtype=object),axis=0))
        np.save(f'pre_evaluated/Task_Time.npy', extracts(np.array(CT, dtype=object),axis=0))
        np.save(f'pre_evaluated/Task_Loss.npy', np.array(Loss, dtype=object))
        np.save(f'pre_evaluated/Task_Fit.npy', extracts(np.array(Fit, dtype=object),axis=0))


    ## Classifier comparision
    Classifier_comparision = False
    if Classifier_comparision:
        FVector = np.load(f'pre_evaluated/Data.npy', allow_pickle=True)
        Target = np.load(f'pre_evaluated/Tar.npy', allow_pickle=True)
        FVector = FVector[1:1000,:].astype(np.float32)
        Target = Target[1:1000].astype(np.float32)
        Target = Target / np.max(Target)
        learn_percent, learning_percentage = [0.6, 0.7, 0.8, 0.9], ['60', '70', '80', '90']
        true_lab, pred_label = [], []
        for lp, lpstr in zip(learn_percent, learning_percentage):
            X_train, X_test, Y_train, Y_test, = train_test_split(FVector,Target, train_size=lp, random_state=0)
            np.save('pre_evaluated/Y_test', Y_test);
            if lp == 0.7:
                np.save('pre_evaluated/ytest70', Y_test);
            true_lab.append(Y_test);
            np.save('pre_evaluated/lp', lp)
            result = [dcnn(),Enet(),Lenet(), Snet(), Lnet(), impLnet()]
            perf = ar([result[i][0] for i in range(len(result))])
            pred = np.array([result[i][1] for i in range(len(result))])
            ct = extract(np.array([result[i][2] for i in range(len(result))]))
            np.save(f'pre_evaluated/comp_time {lpstr}', ct)
            np.save(f'pre_evaluated/pred_label {lpstr}', pred)
            clmn = ['DCNN', 'EfficientNet', 'LeNet', 'SqueezeNet', 'LinkNet', 'PROP']
            indx = ['MSE', 'RMSE', 'MAE', 'MSLE','MAPE', 'MedAE']
            indx2 = ['computational time']
            comtim = np.array(ct)
            globals()['df' + lpstr] = pd.DataFrame(perf.transpose(), columns=clmn, index=indx)
            globals()['df2' + lpstr] = pd.DataFrame(comtim.reshape(1, -1), columns=clmn, index=indx2)

        key = ['60', '70', '80', '90']
        frames = [df60, df70, df80, df90]
        frames2 = [df260, df270, df280, df290]
        df = pd.concat(frames, keys=key, axis=0)
        df2 = pd.concat(frames2, keys=key, axis=0)

        df.to_csv(f'pre_evaluated/Comparision.csv')
        df2.to_csv(f'pre_evaluated/time_result.csv')

        stat = df.loc[(key, ['MSE']), :].values
        stat = stat_analysis(stat).transpose()
        df_ = pd.DataFrame(stat, ['Mean', 'Median', 'Std-Dev', 'Min', 'Max'],
                           ['DCNN', 'EfficientNet', 'LeNet', 'SqueezeNet', 'LinkNet', 'PROP'])
        df_.to_csv(f'pre_evaluated/statistics analysis(MSE).csv')

    ## PlotResult
    # -----Plot Results---------#
    column = ['DCNN', 'EfficientNet', 'LeNet', 'SqueezeNet', 'LinkNet', 'ImpLinkNet']
    plot_result = pd.read_csv(f'pre_evaluated/Comparision.csv', index_col=[0, 1])
    plot_result.to_csv(f'pre_evaluated/Comparision.csv')
    indx = ['MSE', 'RMSE', 'MAE', 'MSLE','MAPE', 'MedAE']

    print('\n\t', Fore.LIGHTBLUE_EX + f'Statistics analysis (MSE)')
    state = pd.read_csv(f'pre_evaluated/statistics analysis(MSE).csv', header=0, names=column)
    print(pd.read_csv(f'pre_evaluated/statistics analysis(MSE).csv', header=0, names=column).to_markdown())
    state.to_csv(f'Results/fullanalysis/Statistics analysis  (MSE).csv')

    print('\n\t', Fore.LIGHTBLUE_EX + f'Computational Time (sec)')
    state = pd.read_csv(f'pre_evaluated/time_result.csv', index_col=[0,1])
    state = state.iloc[-1:]
    print(state.to_markdown())
    state.to_csv(f'Results/fullanalysis/Computational Time (sec).csv')

    colors1 = [ 'lime', 'blue', 'seagreen', 'deepskyblue', 'crimson','magenta']
    hatches = ['//', '..', '\\\\', 'oo', '--', '++', 'xx', '**', '||', '00']
    colors = ['sandybrown', 'slateblue', 'aqua', 'lime', 'blue', 'seagreen', 'deepskyblue', 'crimson','magenta']
    # Analysis plot
    for idx, jj in enumerate(indx):
        new_ = plot_result.loc[([60, 70, 80, 90], [jj]), :]
        new_.reset_index(drop=True, level=1, inplace=True)
        new = new_.values
        bar_plot(new, clr=colors1, index=column, hatches = hatches,xlabel='Training Data (%)',
                   ylable=jj.upper())

    ## Task variation
    column1 = ['SPSO-TCS','RHO','BPSO','RPO','PFO','LOA','KOA','RTH','SIRTH']
    makespan = np.load(f'pre_evaluated/Task_makespan.npy', allow_pickle=True)
    bar_plot1(makespan,1, clr=colors, index=column1, hatches=hatches, xlabel='Task Variation',
                            ylable='Makespan (sec)')
    makespan_stat = stat_analysis1(makespan)
    df1 = pd.DataFrame(makespan_stat, columns=column1, index=['Mean', 'Median', 'Std-Dev', 'Min', 'Max'])
    print('\n\t', Fore.LIGHTBLUE_EX + f'Task Variation vs makespan_stat')
    print(df1.to_markdown())

    deg_imbalance =np.load(f'pre_evaluated/Task_Deg_imbalance.npy', allow_pickle=True)
    bar_plot1(deg_imbalance,1, clr=colors, index=column1, hatches=hatches, xlabel='Task Variation',
                            ylable='Degree of Imbalance')
    deg_imbalance_stat = stat_analysis1(deg_imbalance)
    df2 = pd.DataFrame(deg_imbalance_stat, columns=column1, index=['Mean', 'Median', 'Std-Dev', 'Min', 'Max'])
    print('\n\t', Fore.LIGHTBLUE_EX + f'Task Variation vs Degree of Imbalance_stat')
    print(df2.to_markdown())

    res_util = np.load(f'pre_evaluated/Task_res_utili.npy', allow_pickle=True)
    bar_plot1(res_util,1, clr=colors, index=column1, hatches=hatches, xlabel='Task Variation',
             ylable='Resource Utilization (sec)')
    res_util_stat = stat_analysis1(res_util)
    df3 = pd.DataFrame(res_util_stat, columns=column1, index=['Mean', 'Median', 'Std-Dev', 'Min', 'Max'])
    print('\n\t', Fore.LIGHTBLUE_EX + f'Task Variation vs Resource Utilization_stat')
    print(df3.to_markdown())

    exe_time = np.load(f'pre_evaluated/Task_Exe_time.npy', allow_pickle=True)
    bar_plot1(exe_time,1, clr=colors, index=column1, hatches=hatches, xlabel='Task Variation',
             ylable='Execution Time (sec)')
    exe_time_stat = stat_analysis1(exe_time)
    df4 = pd.DataFrame(exe_time_stat, columns=column1, index=['Mean', 'Median', 'Std-Dev', 'Min', 'Max'])
    print('\n\t', Fore.LIGHTBLUE_EX + f'Task Variation vs Execution Time_stat')
    print(df4.to_markdown())

    # Assuming df1, df2, df3, df4 are already defined
    df1.index = [f'Makespan_{i}' for i in df1.index]
    df2.index = [f'Degree_Imbalance_{i}' for i in df2.index]
    df3.index = [f'Resource_Utilization_{i}' for i in df3.index]
    df4.index = [f'Execution_Time_{i}' for i in df4.index]
    # Combine all DataFrames
    combined_df = pd.concat([df1, df2, df3, df4], axis=0)
    # Save to a single CSV file
    combined_df.to_csv('Results/fullanalysis/Statistics analysis  (Task Variation).csv')


    CT = np.load(f'pre_evaluated/Task_Time.npy', allow_pickle=True)
    df = pd.DataFrame(CT, columns=column1, index=['100', '200', '300', '400'])
    df = df.iloc[-1:]
    print('\n\t', Fore.LIGHTBLUE_EX + f'Task Variation vs Computational Time (sec)')
    print(df.to_markdown())
    df.to_csv(f'Results/fullanalysis/Task Variation vs Computational Time (sec).csv')

    Fit = np.load(f'pre_evaluated/Task_Fit.npy', allow_pickle=True)
    df = pd.DataFrame(Fit, columns=column1, index=['100', '200', '300', '400'])
    print('\n\t', Fore.LIGHTBLUE_EX + f'Task Variation vs Fittness')
    print(df.to_markdown())
    df.to_csv(f'Results/fullanalysis/Task Variation vs Fittness.csv')

    Loss = np.load(f'pre_evaluated/Task_Loss.npy', allow_pickle=True)
    line_graph(Loss[0],1,clr=colors, index=column1, xlabel='Iteration', ylable='Cost Function')

    ## VM variation
    makespan = np.load(f'pre_evaluated/VM_makespan.npy', allow_pickle=True)
    bar_plot1(makespan,2, clr=colors, index=column1, hatches=hatches, xlabel='VM Variation',
                            ylable='Makespan (sec)')
    makespan_stat = stat_analysis1(makespan)
    df1 = pd.DataFrame(makespan_stat, columns=column1, index=['Mean', 'Median', 'Std-Dev', 'Min', 'Max'])
    print('\n\t', Fore.LIGHTBLUE_EX + f'VM Variation vs makespan_stat')
    print(df1.to_markdown())

    deg_imbalance =np.load(f'pre_evaluated/VM_Deg_imbalance.npy', allow_pickle=True)
    bar_plot1(deg_imbalance,2, clr=colors, index=column1, hatches=hatches, xlabel='VM Variation',
                            ylable='Degree of Imbalance')
    deg_imbalance_stat = stat_analysis1(deg_imbalance)
    df2 = pd.DataFrame(deg_imbalance_stat, columns=column1, index=['Mean', 'Median', 'Std-Dev', 'Min', 'Max'])
    print('\n\t', Fore.LIGHTBLUE_EX + f'VM Variation vs Degree of Imbalance_stat')
    print(df2.to_markdown())

    res_util = np.load(f'pre_evaluated/VM_res_utili.npy', allow_pickle=True)
    bar_plot1(res_util,2, clr=colors, index=column1, hatches=hatches, xlabel='VM Variation',
             ylable='Resource Utilization (sec)')
    res_util_stat = stat_analysis1(res_util)
    df3 = pd.DataFrame(res_util_stat, columns=column1, index=['Mean', 'Median', 'Std-Dev', 'Min', 'Max'])
    print('\n\t', Fore.LIGHTBLUE_EX + f'VM Variation vs Resource Utilization_stat')
    print(df3.to_markdown())

    exe_time = np.load(f'pre_evaluated/VM_Exe_time.npy', allow_pickle=True)
    bar_plot1(exe_time, 2, clr=colors, index=column1, hatches=hatches, xlabel='VM Variation',
              ylable='Execution Time (sec)')
    exe_time_stat = stat_analysis1(exe_time)
    df4 = pd.DataFrame(exe_time_stat, columns=column1, index=['Mean', 'Median', 'Std-Dev', 'Min', 'Max'])
    print('\n\t', Fore.LIGHTBLUE_EX + f'VM vs Execution Time_stat')
    print(df4.to_markdown())

    # Assuming df1, df2, df3, df4 are already defined
    df1.index = [f'Makespan_{i}' for i in df1.index]
    df2.index = [f'Degree_Imbalance_{i}' for i in df2.index]
    df3.index = [f'Resource_Utilization_{i}' for i in df3.index]
    df4.index = [f'Execution_Time_{i}' for i in df4.index]
    # Combine all DataFrames
    combined_df = pd.concat([df1, df2, df3, df4], axis=0)
    # Save to a single CSV file
    combined_df.to_csv('Results/fullanalysis/Statistics analysis  (VM Variation).csv')


    CT = np.load(f'pre_evaluated/VM_Time.npy', allow_pickle=True)
    df = pd.DataFrame(CT, columns=column1, index=['10', '20', '30', '40', '50'])
    df = df.iloc[-1:]
    print('\n\t', Fore.LIGHTBLUE_EX + f'VM Variation vs Computational Time (sec)')
    print(df.to_markdown())
    df.to_csv(f'Results/fullanalysis/VM Variation vs Computational Time (sec).csv')

    Fit = extracts(np.load(f'pre_evaluated/VM_Fit.npy', allow_pickle=True),axis=1)
    df = pd.DataFrame(Fit, columns=column1, index=['10', '20', '30', '40', '50'])
    print('\n\t', Fore.LIGHTBLUE_EX + f'VM Variation vs Fittness')
    print(df.to_markdown())
    df.to_csv(f'Results/fullanalysis/VM Variation vs Fittness.csv')

    Loss = np.load(f'pre_evaluated/VM_Loss.npy', allow_pickle=True)
    line_graph(Loss[0],2,clr=colors, index=column1, xlabel='Iteration', ylable='Cost Function')

else:

    result.result()



